import React, { useState } from "react";
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Linking,
  Alert,
} from "react-native";

const schemes = [
  {
    id: "central",
    name: "Central Government Schemes",
    department: "Government of India",
    categories: [
      "student", "farmer", "business", "women",
      "health", "housing", "social", "employment",
    ],
    description:
      "Discover central schemes, benefits, eligibility rules and application instructions.",
    documents: "Check the documents listed on the official scheme page.",
    url: "https://www.myscheme.gov.in/",
    source: "National scheme directory",
  },
  {
    id: "ap-services",
    name: "Andhra Pradesh Government Services",
    department: "Government of Andhra Pradesh",
    categories: [
      "student", "farmer", "business", "women",
      "health", "housing", "social", "employment",
    ],
    description:
      "Explore Andhra Pradesh government services and find relevant department information.",
    documents: "Requirements depend on the selected service.",
    url: "https://services.india.gov.in/service/detail/services-portal-of-andhra-pradesh-government",
    source: "Government services portal",
  },
  {
    id: "education",
    name: "Education & Scholarship Search",
    department: "Central and State scheme directories",
    categories: ["student"],
    description:
      "Find scholarships and education support. Check course, income, marks and category conditions.",
    documents: "May include study certificates, marksheets and income or category certificates.",
    url: "https://www.myscheme.gov.in/",
    source: "Verify each scheme's official rules",
  },
  {
    id: "agriculture",
    name: "Agriculture Support Search",
    department: "Central and State scheme directories",
    categories: ["farmer"],
    description:
      "Explore agricultural assistance and check land, occupation and other scheme-specific conditions.",
    documents: "Requirements vary by scheme; check its official guidelines.",
    url: "https://www.myscheme.gov.in/",
    source: "Verify each scheme's official rules",
  },
  {
    id: "employment",
    name: "Employment & Self-Employment Search",
    department: "Central and State scheme directories",
    categories: ["employment", "business"],
    description:
      "Explore skill training, employment support and eligible self-employment programmes.",
    documents: "Check the selected programme's application requirements.",
    url: "https://www.myscheme.gov.in/",
    source: "Verify each scheme's official rules",
  },
  {
    id: "social",
    name: "Social Welfare Scheme Search",
    department: "Central and State scheme directories",
    categories: ["social", "women", "health", "housing"],
    description:
      "Explore welfare support and verify the conditions applicable to your circumstances.",
    documents: "Documents depend on the particular welfare scheme.",
    url: "https://www.myscheme.gov.in/",
    source: "Verify each scheme's official rules",
  },
];

const interests = [
  { label: "Student", value: "student" },
  { label: "Farmer", value: "farmer" },
  { label: "Business", value: "business" },
  { label: "Employment", value: "employment" },
  { label: "Women", value: "women" },
  { label: "Health", value: "health" },
  { label: "Housing", value: "housing" },
  { label: "Social welfare", value: "social" },
];

export default function App() {
  const [age, setAge] = useState("");
  const [income, setIncome] = useState("");
  const [occupation, setOccupation] = useState("student");
  const [selected, setSelected] = useState(["student"]);
  const [searched, setSearched] = useState(false);
  const [results, setResults] = useState([]);

  function toggleInterest(value) {
    setSelected((old) =>
      old.includes(value)
        ? old.filter((item) => item !== value)
        : [...old, value]
    );
  }

  function findSchemes() {
    if (
      !age.trim() ||
      !income.trim() ||
      !Number.isFinite(Number(age)) ||
      !Number.isFinite(Number(income)) ||
      Number(age) < 0 ||
      Number(age) > 120 ||
      Number(income) < 0
    ) {
      Alert.alert(
        "Check your details",
        "Enter a valid age and annual family income."
      );
      return;
    }

    if (selected.length === 0) {
      Alert.alert("Choose a category", "Select at least one interest.");
      return;
    }

    const matches = schemes.filter((scheme) =>
      scheme.categories.some((category) => selected.includes(category))
    );

    setResults(matches);
    setSearched(true);
  }

  async function openOfficialSite(url) {
    try {
      await Linking.openURL(url);
    } catch {
      Alert.alert("Unable to open link", "Please try again in your browser.");
    }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.hero}>
          <Text style={styles.eyebrow}>CITIZEN FIRST • INDIA</Text>
          <Text style={styles.title}>Government{"\n"}Scheme Finder</Text>
          <Text style={styles.subtitle}>
            Find relevant government support. Understand the rules.
            Discover where to apply.
          </Text>
          <View style={styles.pill}>
            <Text style={styles.pillText}>
              Andhra Pradesh + Central Government
            </Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Tell us about yourself</Text>
        <Text style={styles.helper}>
          Basic details help you explore relevant scheme categories.
        </Text>

        <Text style={styles.label}>Your age</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter age in years"
          placeholderTextColor="#7C8798"
          keyboardType="number-pad"
          value={age}
          onChangeText={setAge}
          maxLength={3}
        />

        <Text style={styles.label}>Annual family income (₹)</Text>
        <TextInput
          style={styles.input}
          placeholder="Example: 150000"
          placeholderTextColor="#7C8798"
          keyboardType="number-pad"
          value={income}
          onChangeText={setIncome}
          maxLength={10}
        />

        <Text style={styles.label}>Main occupation</Text>
        <View style={styles.chips}>
          {interests.slice(0, 4).map((item) => (
            <TouchableOpacity
              key={item.value}
              onPress={() => setOccupation(item.value)}
              style={[
                styles.chip,
                occupation === item.value && styles.chipSelected,
              ]}
            >
              <Text
                style={[
                  styles.chipText,
                  occupation === item.value && styles.chipTextSelected,
                ]}
              >
                {item.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.label}>What support are you looking for?</Text>
        <View style={styles.chips}>
          {interests.map((item) => {
            const active = selected.includes(item.value);
            return (
              <TouchableOpacity
                key={item.value}
                onPress={() => toggleInterest(item.value)}
                style={[
                  styles.chip,
                  active && styles.chipSelected,
                ]}
              >
                <Text
                  style={[
                    styles.chipText,
                    active && styles.chipTextSelected,
                  ]}
                >
                  {active ? "✓ " : "+ "}{item.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <TouchableOpacity style={styles.primary} onPress={findSchemes}>
          <Text style={styles.primaryText}>Find Relevant Schemes →</Text>
        </TouchableOpacity>

        {searched && (
          <View>
            <Text style={styles.sectionTitle}>
              Your discovery results ({results.length})
            </Text>
            <Text style={styles.helper}>
              These are relevant directories and search categories,
              not confirmed eligibility decisions.
            </Text>

            {results.map((scheme) => (
              <View key={scheme.id} style={styles.card}>
                <Text style={styles.badge}>POTENTIAL MATCH</Text>
                <Text style={styles.cardTitle}>{scheme.name}</Text>
                <Text style={styles.department}>{scheme.department}</Text>
                <Text style={styles.description}>
                  {scheme.description}
                </Text>
                <Text style={styles.label}>Documents</Text>
                <Text style={styles.description}>
                  {scheme.documents}
                </Text>
                <TouchableOpacity
                  style={styles.secondary}
                  onPress={() => openOfficialSite(scheme.url)}
                >
                  <Text style={styles.secondaryText}>
                    Visit Official Portal ↗
                  </Text>
                </TouchableOpacity>
                <Text style={styles.source}>{scheme.source}</Text>
              </View>
            ))}
          </View>
        )}

        <View style={styles.notice}>
          <Text style={styles.noticeTitle}>Important</Text>
          <Text style={styles.noticeText}>
            This starter version does not verify scheme eligibility.
            It does not submit applications or guarantee benefits.
            Always confirm current rules, deadlines and documents
            on the official scheme page before applying.
          </Text>
        </View>

        <Text style={styles.footer}>
          GOVERNMENT SCHEME FINDER • STARTER VERSION
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F4F7FB" },
  container: { padding: 20, paddingBottom: 40 },
  hero: {
    backgroundColor: "#12284C",
    padding: 24,
    borderRadius: 22,
    marginBottom: 26,
  },
  eyebrow: {
    color: "#93C5FD",
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 2,
  },
  title: {
    color: "#FFFFFF",
    fontSize: 34,
    fontWeight: "900",
    marginTop: 12,
    lineHeight: 40,
  },
  subtitle: {
    color: "#D9E6F7",
    fontSize: 14,
    lineHeight: 22,
    marginTop: 12,
  },
  pill: {
    alignSelf: "flex-start",
    backgroundColor: "#29466F",
    padding: 9,
    borderRadius: 20,
    marginTop: 18,
  },
  pillText: { color: "#FFFFFF", fontSize: 11, fontWeight: "700" },
  sectionTitle: {
    color: "#14233B",
    fontSize: 22,
    fontWeight: "800",
    marginTop: 12,
  },
  helper: {
    color: "#627087",
    fontSize: 13,
    lineHeight: 20,
    marginTop: 6,
    marginBottom: 14,
  },
  label: {
    color: "#26364D",
    fontWeight: "700",
    fontSize: 13,
    marginTop: 15,
    marginBottom: 8,
  },
  input: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#DCE3ED",
    padding: 15,
    borderRadius: 12,
    fontSize: 15,
    color: "#14233B",
  },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#DCE3ED",
    paddingHorizontal: 13,
    paddingVertical: 11,
    borderRadius: 24,
  },
  chipSelected: {
    backgroundColor: "#DCEBFF",
    borderColor: "#2866C5",
  },
  chipText: { color: "#46546A", fontSize: 12, fontWeight: "600" },
  chipTextSelected: { color: "#174B9B" },
  primary: {
    backgroundColor: "#2463D4",
    padding: 17,
    alignItems: "center",
    borderRadius: 13,
    marginTop: 25,
    marginBottom: 18,
  },
  primaryText: { color: "#FFFFFF", fontSize: 15, fontWeight: "800" },
  card: {
    backgroundColor: "#FFFFFF",
    padding: 17,
    borderRadius: 17,
    marginTop: 13,
    borderWidth: 1,
    borderColor: "#E2E8F0",
  },
  badge: {
    color: "#1D5AB6",
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1,
  },
  cardTitle: {
    color: "#14233B",
    fontSize: 18,
    fontWeight: "800",
    marginTop: 9,
  },
  department: { color: "#627087", fontSize: 12, marginTop: 5 },
  description: {
    color: "#46546A",
    fontSize: 13,
    lineHeight: 20,
    marginTop: 9,
  },
  secondary: {
    borderWidth: 1,
    borderColor: "#2463D4",
    padding: 12,
    alignItems: "center",
    borderRadius: 10,
    marginTop: 15,
  },
  secondaryText: { color: "#2463D4", fontWeight: "800", fontSize: 13 },
  source: { color: "#64748B", fontSize: 11, marginTop: 10 },
  notice: {
    backgroundColor: "#FFF4D8",
    padding: 16,
    borderRadius: 14,
    marginTop: 25,
  },
  noticeTitle: { color: "#80520B", fontWeight: "900", fontSize: 14 },
  noticeText: {
    color: "#775B2A",
    fontSize: 12,
    lineHeight: 19,
    marginTop: 6,
  },
  footer: {
    color: "#8A96A8",
    textAlign: "center",
    fontSize: 10,
    marginTop: 25,
    letterSpacing: 1,
  },
});